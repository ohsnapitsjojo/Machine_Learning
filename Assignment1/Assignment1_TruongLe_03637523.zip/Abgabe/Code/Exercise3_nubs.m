function [ output_args ] = Exercise3_nubs( gesture_l, gesture_o, gesture_x, k )
%EXERCISE3_NUBS Summary of this function goes here
%   Detailed explanation goes here
    nubs(gesture_l, k);
    nubs(gesture_x, k);
    nubs(gesture_o, k);


end

